Responsive HTML5 website template for developers

Theme name:
=======================================================================
devAid

Theme version:
=======================================================================
v1.1

Release Date:
=======================================================================
07 Jan 2016

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media (http://themes.3rdwavemedia.com/)

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: hello@3rdwavemedia.com
Twitter: @3rdwave_themes

License: 
=======================================================================
This template is free under the Creative Commons Attribution 3.0 License.
https://creativecommons.org/licenses/by/3.0/

If you'd like to use the template without the attribution, you can check out other license options via our website: http://themes.3rdwavemedia.com/
